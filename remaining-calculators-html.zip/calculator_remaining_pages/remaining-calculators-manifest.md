# Remaining Calculator Build

Total calculators: **35**

## Automotive (8)

- `9-automotive/gas-mileage.html` - Gas Mileage Calculator
- `9-automotive/car-payment.html` - Car Payment Calculator
- `9-automotive/fuel-cost.html` - Fuel Cost Calculator
- `9-automotive/tire-pressure.html` - Tire Pressure Calculator
- `9-automotive/lease-vs-buy.html` - Lease vs Buy Calculator
- `9-automotive/depreciation.html` - Car Depreciation Calculator
- `9-automotive/road-trip-cost.html` - Road Trip Cost Calculator
- `9-automotive/ev-charging-cost.html` - EV Charging Cost Calculator

## Personal (10)

- `8-personal/age-difference.html` - Age Difference Calculator
- `8-personal/baby-due-date.html` - Baby Due Date Calculator
- `8-personal/days-until.html` - Days Until Calculator
- `8-personal/anniversary-calculator.html` - Anniversary Calculator
- `8-personal/sleep-cycle.html` - Sleep Cycle Calculator
- `8-personal/pet-age.html` - Pet Age Calculator
- `8-personal/zodiac-sign.html` - Zodiac Sign Calculator
- `8-personal/life-path-number.html` - Life Path Number Calculator
- `8-personal/love-calculator.html` - Love Calculator
- `8-personal/retirement-countdown.html` - Retirement Countdown Calculator

## Health & Fitness (17)

- `7-fitness/bmi.html` - BMI Calculator
- `7-fitness/bmr.html` - BMR Calculator
- `7-fitness/tdee.html` - TDEE Calculator
- `7-fitness/calorie-needs.html` - Calorie Needs Calculator
- `7-fitness/protein-intake.html` - Protein Intake Calculator
- `7-fitness/body-fat-percentage.html` - Body Fat Percentage Calculator
- `7-fitness/waist-hip-ratio.html` - Waist-Hip Ratio Calculator
- `7-fitness/ideal-weight.html` - Ideal Weight Calculator
- `7-fitness/max-heart-rate.html` - Max Heart Rate Calculator
- `7-fitness/one-rep-max.html` - One Rep Max Calculator
- `7-fitness/calorie-burn.html` - Calorie Burn Calculator
- `7-fitness/vo2-max.html` - VO2 Max Calculator
- `7-fitness/bmi-percentile.html` - BMI Percentile Calculator for Kids
- `7-fitness/bac-calculator.html` - BAC Calculator
- `7-fitness/pregnancy-calculator.html` - Pregnancy Week Calculator
- `7-fitness/water-intake.html` - Water Intake Calculator
- `7-fitness/pace-calculator.html` - Pace Calculator
